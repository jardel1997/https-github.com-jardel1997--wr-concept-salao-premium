const IMG={"por": "images/wr-por.jpg", "kid": "images/wr-kid.jpg", "fac": "images/wr-fac.jpg", "lav": "images/wr-lav.jpg", "est": "images/wr-est.jpg", "br": "images/wr-br.jpg", "dup": "images/wr-dup.jpg", "sel": "images/wr-sel.jpg", "lg": "images/wr-lg.jpg", "lw": "images/wr-lw.jpg", "up": "images/wr-up.jpg", "lb": "images/wr-lb.jpg", "ro": "images/wr-ro.jpg", "sm": "images/wr-sm.jpg"},CONFIG={whatsapp:"5511944705608",instagram:"https://instagram.com/wrconcept_",googleReviews:"",facebook:"",tiktok:"",gm:"https://www.google.com/maps/dir/?api=1&destination="+encodeURIComponent("WR Concept, Rua Lord Clemente Attlee 70, Chácara Inglesa, São Paulo SP 05142-020")};
const $=s=>document.querySelectorAll(s);
$('[data-i]').forEach(e=>e.src=IMG[e.dataset.i]);
const L=(s,u)=>$(s).forEach(a=>{if(u){a.href=u;a.target='_blank';a.rel='noopener'}else{a.setAttribute('aria-disabled','true');a.title='Link oficial ainda não configurado'}});
L('[data-wa]','https://wa.me/'+CONFIG.whatsapp+'?text='+encodeURIComponent('Olá! Gostaria de agendar um horário no WR Concept.'));
L('[data-ig]',CONFIG.instagram);L('[data-fb]',CONFIG.facebook);L('[data-tt]',CONFIG.tiktok);L('[data-gm]',CONFIG.gm);L('[data-gr]',CONFIG.googleReviews);
$('[aria-disabled]').forEach(a=>a.addEventListener('click',e=>e.preventDefault()));
const tr=document.getElementById('tr'),ks=['br','ro','lw','up','lb','sel','lg','dup','kid'],al={};
tr.innerHTML=[...ks,...ks].map(k=>`<img class="arc" src="${IMG[k]}" alt="${al[k]||'Resultado de coloração e luzes do WR Concept'}" draggable="false">`).join('');
const ic={'Estacionamento':['Garagem gratuita, vagas na rua e estacionamento próprio.','M5 20V4h7a4 4 0 010 8H5'],'Acessibilidade':['Vaga de estacionamento para cadeirantes.','M12 5a1.5 1.5 0 100-.01M12 8v6h4l2 5M9 12a5 5 0 105 7'],'Wi-Fi gratuito':['Conexão livre para clientes.','M3 9a14 14 0 0118 0M6 13a9 9 0 0112 0M9 16a4 4 0 016 0M12 19v.01'],'Banheiro':['Banheiro disponível para clientes.','M6 3h12v18H6zM12 3v18'],'Espaço acolhedor':['Ambiente adequado para crianças.','M12 21s-8-5-8-11a4.5 4.5 0 018-2.5A4.5 4.5 0 0120 10c0 6-8 11-8 11z'],'Inclusivo e seguro':['Amigável ao público LGBTQ+ e seguro para pessoas trans.','M12 3l2.5 6 6.5.5-5 4.3 1.6 6.4L12 16.5 6.4 20.2 8 13.8 3 9.5 9.5 9z']};
const sk=['fac','est','lav'],sa={fac:'Fachada do WR Concept com letreiro escuro e vitrine de vidro',est:'Bancadas com espelhos iluminados e cadeiras pretas no WR Concept',lav:'Lavatórios com cadeiras reclináveis e a marca WR Concept'};
document.getElementById('tr2').innerHTML=[...sk,...sk,...sk,...sk].map(k=>`<img class="arc" src="${IMG[k]}" alt="${sa[k]}" draggable="false">`).join('');
document.getElementById('g6').innerHTML=Object.entries(ic).map(([t,[d,p]])=>`<div class="c" data-r><svg viewBox="0 0 24 24" aria-hidden="true"><path d="${p}"/></svg><h3>${t}</h3><p>${d}</p></div>`).join('');
const star=(f)=>`<svg viewBox="0 0 24 24" aria-hidden="true"><defs><linearGradient id="g${f}"><stop offset="${f}%" stop-color="#FBBC04"/><stop offset="${f}%" stop-color="#FBBC0433"/></linearGradient></defs><path fill="url(#g${f})" d="M12 2l3 6.9 7.5.7-5.7 5 1.7 7.4L12 18l-6.5 4 1.7-7.4-5.7-5L9 8.9z"/></svg>`;
document.getElementById('stars').innerHTML=star(100).repeat(4)+star(90);
const io=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;e.target.classList.add('on');io.unobserve(e.target);
 if(e.target.id=='pv'){const t0=performance.now(),f=n=>{const p=Math.min(1,(n-t0)/1800),q=1-Math.pow(1-p,3);n1.textContent=(4.9*q).toFixed(1).replace('.',',');n2.textContent=Math.round(144*q);p<1&&requestAnimationFrame(f)};requestAnimationFrame(f)}}),{threshold:.35});
$('[data-r]').forEach(e=>io.observe(e));
(()=>{const s=document.getElementById('idn'),p=[...s.querySelectorAll('.pn')];let i=0,t=0,u=0;const set=n=>p.forEach((e,k)=>e.classList.toggle('a',k==n));p.forEach((e,k)=>{e.setAttribute('role','button');e.tabIndex=0;e.setAttribute('aria-expanded','false');const go=()=>{const o=!e.classList.contains('a');set(o?k:-1);p.forEach((q,j)=>q.setAttribute('aria-expanded',o&&j==k))};e.addEventListener('click',go);e.addEventListener('keydown',ev=>{if(ev.key=='Enter'||ev.key==' '){ev.preventDefault();go()}})})})();
const hd=document.getElementById('hd');addEventListener('scroll',()=>hd.classList.toggle('s',scrollY>60),{passive:true});
(()=>{const p=new Intl.DateTimeFormat('en-US',{timeZone:'America/Sao_Paulo',weekday:'short',hour:'numeric',hour12:false}).formatToParts(new Date()),d=p.find(x=>x.type=='weekday').value,h=+p.find(x=>x.type=='hour').value%24,o=!['Sun','Mon'].includes(d)&&h>=9&&h<19;const e=document.getElementById('open');e.textContent=o?'Aberto agora':'Fechado'})();

$('.bd').forEach((e,i)=>e.style.setProperty('--b'+i,'url('+IMG[['sel','lw','kid'][i]]+')'));$('.bd').forEach((e,i)=>e.style.backgroundImage='url('+IMG[['sel','lw','kid'][i]]+')');
const mb=document.getElementById('mb'),ov=document.getElementById('ov'),tg=o=>{ov.classList.toggle('o',o);mb.setAttribute('aria-expanded',o);mb.textContent=o?'Fechar':'Menu'};
mb.onclick=()=>tg(!ov.classList.contains('o'));addEventListener('keydown',e=>e.key=='Escape'&&tg(false));ov.querySelectorAll('a').forEach(a=>a.onclick=()=>tg(false));document.getElementById('cl').onclick=()=>tg(false);
const fitMenu=()=>{const as=[...ov.querySelectorAll('a')];ov.style.removeProperty('--fs');for(let k=0;k<3;k++){let m=0,av=1e9;as.forEach(a=>{m=Math.max(m,a.firstElementChild.offsetWidth);av=Math.min(av,a.clientWidth)});if(m<=av)break;const f=parseFloat(getComputedStyle(as[0]).fontSize);ov.style.setProperty('--fs',(f*av/m*.95)+'px')}};fitMenu();addEventListener('resize',fitMenu);addEventListener('load',fitMenu);mb.addEventListener('click',fitMenu);if(document.fonts){document.fonts.ready.then(fitMenu);document.fonts.addEventListener('loadingdone',fitMenu);document.fonts.load('500 40px "Bodoni Moda"').then(fitMenu)}
new IntersectionObserver(([e])=>hd.classList.toggle('logo-ready',!e.isIntersecting)).observe(document.getElementById('story'));
window.__wrReady=1;
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches,root=document.documentElement;
if(!RM&&window.gsap&&window.ScrollTrigger){let run=true,P=0,R,S,C;root.classList.add('fx');try{gsap.registerPlugin(ScrollTrigger);ScrollTrigger.config({ignoreMobileResize:true});
try{const mob=innerWidth<800;R=new THREE.WebGLRenderer({canvas:cv,alpha:true,antialias:false,powerPreference:'low-power'});R.setPixelRatio(1);S=new THREE.Scene();C=new THREE.PerspectiveCamera(60,1,.1,200);const cs=[0xE0A25A,0xF3C98B,0xFFF1D6,0x8A4B1F,0xC9803F];
for(let i=0;i<(mob?70:130);i++){const p=[],a=Math.random()*6.28,r=3+Math.random()*9,h=Math.random()*6;for(let j=0;j<25;j++)p.push(new THREE.Vector3(Math.cos(a+j*.3+h)*r+Math.sin(j*.5+h)*2,Math.sin(a+j*.25)*r*.6+Math.cos(j*.4+h)*2,10-j*4));
S.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(new THREE.CatmullRomCurve3(p).getPoints(150)),new THREE.LineBasicMaterial({color:cs[i%5],transparent:true,opacity:.35+Math.random()*.5})))}
const rs=()=>{R.setSize(innerWidth,innerHeight,false);C.aspect=innerWidth/innerHeight;C.updateProjectionMatrix()};rs();addEventListener('resize',rs);
gsap.ticker.add(t=>{if(!run)return;C.position.set(Math.sin(t*.4)*1.2,Math.cos(t*.3)*.8,12-P*80+Math.sin(t*.2)*1.5);C.rotation.z=Math.sin(t*.25)*.05;R.render(S,C)})}catch(e){cv.style.display='none'}
gsap.set('#t1',{opacity:1});gsap.set('#ex',{transformPerspective:1200});
const tl=gsap.timeline({defaults:{ease:'none'},scrollTrigger:{trigger:'#story',start:'top top',end:'+=520%',pin:true,scrub:1,anticipatePin:1,onUpdate:s=>{P=s.progress;pg.style.transform='scaleX('+P+')'},onLeave:()=>run=false,onEnterBack:()=>run=true}});
tl.to('#mp',{scale:1.4,duration:3.4},0).to('#cv',{opacity:.9,duration:2},0).to('#t1',{yPercent:-40,duration:1.2},.5).to('#t1',{opacity:0,duration:1.2},.5)
.fromTo('#t2',{opacity:0},{opacity:1,duration:.3},1.4).to('#t2',{opacity:0,duration:.3},2.8);
[0,1,2,3].forEach(i=>{const c=$('.cd')[i],x=[-30,-10,10,30][i]+'vw',s=1.3+i*.4;tl.fromTo(c,{z:-2600,x:x,rotationY:(i-1.5)*-25},{z:700,duration:1.6,ease:'power1.in'},s).fromTo(c,{opacity:0},{opacity:1,duration:.4},s).to(c,{opacity:0,duration:.4},s+1.2)});
tl.to('#mp',{xPercent:-120,rotationY:35,duration:1.5,ease:'power2.in'},3.3).to('#rv',{clipPath:'inset(0 0 0 0%)',duration:1.5},3.3).fromTo('#rv img',{scale:1.4},{scale:1,duration:1.5},3.3)
.fromTo('#t3',{opacity:0},{opacity:1,duration:.3},3.9).to('#t3',{opacity:0,duration:.3},4.4).to('#rv',{opacity:0,scale:1.15,duration:.3},4.8)
.fromTo('#bands',{opacity:0},{opacity:1,duration:.2},5).fromTo('.bd',{yPercent:i=>i%2?120:-120,opacity:0},{yPercent:0,opacity:1,duration:.9,stagger:.25},5)
.fromTo('#t4',{opacity:0},{opacity:1,duration:.3},5.1).to('#t4',{opacity:0,duration:.3},6.8).to('#bands',{opacity:0,xPercent:-8,duration:.3},7.1)
.to('#cv',{opacity:.35,duration:.8},7.9).fromTo('#ex',{opacity:0,rotationY:-70,x:'30vw'},{opacity:1,rotationY:0,x:0,duration:1},7.9).to({},{duration:.1},9.9);
const rf=()=>ScrollTrigger.refresh();addEventListener('load',rf);if(document.fonts)document.fonts.ready.then(rf);
}catch(err){console.warn('WR: animações desativadas, usando layout estático.',err);run=false;try{ScrollTrigger.getAll().forEach(t=>t.kill(true));gsap.ticker.lagSmoothing(500,33)}catch(e){}root.classList.remove('fx')}}

function marq(el,dir,sp,rx,bm=18,nm=0){let x=0,b=0,dr=0,sx=0,x0=0,last=scrollY,init=0;el.style.animation='none';
el.addEventListener('pointerdown',e=>{dr=1;sx=e.clientX;x0=x;el.setPointerCapture(e.pointerId);el.style.cursor='grabbing'});
el.addEventListener('pointermove',e=>{if(dr)x=x0+e.clientX-sx});
['pointerup','pointercancel'].forEach(n=>el.addEventListener(n,()=>{dr=0;el.style.cursor=''}));
let on=1;new IntersectionObserver(([e])=>on=e.isIntersecting).observe(el.parentElement);(function f(){const now=performance.now(),k=nm?Math.min(3,(now-(f.t||now))/16.667):1;f.t=now;const W=el.scrollWidth/2;if(on&&W>0){if(!init){init=1;if(dir>0)x=-W}const d=Math.abs(scrollY-last);last=scrollY;b=Math.min(bm,b+d/90)*.92;
if(!dr)x+=dir*(sp+(rx?b:0))*k;while(x<=-W)x+=W;while(x>0)x-=W;el.style.transform='translate3d('+x+'px,0,0)'}requestAnimationFrame(f)})()}
if(!matchMedia('(prefers-reduced-motion:reduce)').matches){marq(document.getElementById('tr2'),-1,.6,true,4,1);marq(document.getElementById('tr'),-1,.7,true)}
addEventListener('pointermove',e=>{sp.style.transform='translate3d('+e.clientX+'px,'+e.clientY+'px,0)'});
